x<-as.integer(readline(prompt="Enter any Number : "))
n<-2
count <- 1
repeat{
	if(x>n){
		if((x %% n)== 0){
			count=count+1
}
n=n+1
}else{
	print("Not Prime")
}
}


	
